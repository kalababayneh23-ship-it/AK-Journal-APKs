# A.K Journal Pro 2.0
A polished Android trading journal UI inspired by modern trading journals such as TradeZella/Tradervue-style workflows. It is an original interface, not a copy of proprietary branding/assets.
Features: Dashboard, equity curve, trade journal, analytics by symbol/setup/day, risk calculator, R:R, local on-device storage, quick risk buttons, notes/emotions.
