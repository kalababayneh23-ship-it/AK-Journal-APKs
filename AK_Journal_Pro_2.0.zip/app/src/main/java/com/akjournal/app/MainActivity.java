package com.akjournal.app;
import android.app.*; import android.os.*; import android.webkit.*; import android.view.*; import android.graphics.Color;

public class MainActivity extends Activity {
  WebView w;
  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(10,13,18)); w=new WebView(this);
    w.setBackgroundColor(Color.rgb(10,13,18)); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true); w.setOverScrollMode(View.OVER_SCROLL_NEVER); w.loadUrl("file:///android_asset/index.html"); setContentView(w);}
  @Override public void onBackPressed(){ if(w.canGoBack()) w.goBack(); else super.onBackPressed(); }
}
